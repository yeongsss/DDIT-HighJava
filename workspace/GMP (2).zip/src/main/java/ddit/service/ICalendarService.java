package ddit.service;

import java.util.List;

import ddit.vo.ScheduleMemberVO;


public interface ICalendarService {
	
	public int insertSchedule(ScheduleMemberVO vo);
	
	public List<ScheduleMemberVO> loadSchedule(int mem_no);
	
	public int deleteOneSchedule(int idx);
	
	public int deleteAllSchedule();
	
}
