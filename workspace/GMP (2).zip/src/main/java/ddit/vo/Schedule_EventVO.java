package ddit.vo;


public class Schedule_EventVO {
	
	private String title;
	private String start;
	private String end;
	private String allDayStr;
	private boolean allDay;
	private String id;
	private int idx;
	
	
	
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getStart() {
		return start;
	}
	public void setStart(String start) {
		this.start = start;
	}
	public String getEnd() {
		return end;
	}
	public void setEnd(String end) {
		this.end = end;
	}
	public String getAllDayStr() {
		return allDayStr;
	}
	public void setAllDayStr(String allDaystr) {
		this.allDayStr = allDaystr;
	}
	public boolean isAllDay() {
		return allDay;
	}
	public void setAllDay(boolean allDay) {
		this.allDay = allDay;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	
	
	
}
