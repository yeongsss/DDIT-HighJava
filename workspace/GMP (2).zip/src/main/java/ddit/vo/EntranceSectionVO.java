package ddit.vo;

public class EntranceSectionVO {

	private int ent_id;
	private int esec_idx;
	private int mem_no;
	
	public EntranceSectionVO() {}

	public EntranceSectionVO(int ent_id, int esec_idx, int mem_no) {
		this.ent_id = ent_id;
		this.esec_idx = esec_idx;
		this.mem_no = mem_no;
	}

	public int getEnt_id() {
		return ent_id;
	}

	public void setEnt_id(int ent_id) {
		this.ent_id = ent_id;
	}

	public int getEsec_idx() {
		return esec_idx;
	}

	public void setEsec_idx(int esec_idx) {
		this.esec_idx = esec_idx;
	}

	public int getMem_no() {
		return mem_no;
	}

	public void setMem_no(int mem_no) {
		this.mem_no = mem_no;
	}

	@Override
	public String toString() {
		return "EntranceSectionVO [ent_id=" + ent_id + ", esec_idx=" + esec_idx + ", mem_no=" + mem_no + "]";
	}
	
}
