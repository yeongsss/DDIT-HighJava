package ddit.vo;

public class ChatVO {

	private int chat_no;
	private int mem_no;

	public ChatVO() {}

	public ChatVO(int chat_no, int mem_no) {
		this.chat_no = chat_no;
		this.mem_no = mem_no;
	}

	public int getChat_no() {
		return chat_no;
	}

	public void setChat_no(int chat_no) {
		this.chat_no = chat_no;
	}

	public int getMem_no() {
		return mem_no;
	}

	public void setMem_no(int mem_no) {
		this.mem_no = mem_no;
	}

	@Override
	public String toString() {
		return "ChatVO [chat_no=" + chat_no + ", mem_no=" + mem_no + "]";
	}
	
}
