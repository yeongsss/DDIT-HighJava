package ddit.vo;

public class ScheduleSectionVO {

	private int ssec_no;
	private int dept_no;
	private String ssec_nm;
	
	public ScheduleSectionVO() {}

	public ScheduleSectionVO(int ssec_no, int dept_no, String ssec_nm) {
		this.ssec_no = ssec_no;
		this.dept_no = dept_no;
		this.ssec_nm = ssec_nm;
	}

	public int getSsec_no() {
		return ssec_no;
	}

	public void setSsec_no(int ssec_no) {
		this.ssec_no = ssec_no;
	}

	public int getDept_no() {
		return dept_no;
	}

	public void setDept_no(int dept_no) {
		this.dept_no = dept_no;
	}

	public String getSsec_nm() {
		return ssec_nm;
	}

	public void setSsec_nm(String ssec_nm) {
		this.ssec_nm = ssec_nm;
	}

	@Override
	public String toString() {
		return "ScheduleSectionVO [ssec_no=" + ssec_no + ", dept_no=" + dept_no + ", ssec_nm=" + ssec_nm + "]";
	}

}
