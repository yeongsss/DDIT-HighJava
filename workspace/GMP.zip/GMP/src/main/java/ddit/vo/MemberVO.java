package src.main.java.ddit.vo;

public class MemberVO {
    private int mem_no;
	private String dept_no;
	private String posi_no;
	private String mem_nm;
	private String mem_tel;
	private String mem_addr1;
	private String mem_addr2;
	private String mem_birth;
	private String mem_id;
	private String mem_pw;
	private String mem_mail;
	private String hire;
	private String retire;
	private int auth;
	
	public MemberVO() {	}

	public MemberVO(int mem_no, String dept_no, String posi_no, String mem_nm, String mem_tel, String mem_addr1,
			String mem_addr2, String mem_birth, String mem_id, String mem_pw, String mem_mail, String hire,
			String retire) {
		this.mem_no = mem_no;
		this.dept_no = dept_no;
		this.posi_no = posi_no;
		this.mem_nm = mem_nm;
		this.mem_tel = mem_tel;
		this.mem_addr1 = mem_addr1;
		this.mem_addr2 = mem_addr2;
		this.mem_birth = mem_birth;
		this.mem_id = mem_id;
		this.mem_pw = mem_pw;
		this.mem_mail = mem_mail;
		this.hire = hire;
		this.retire = retire;
	}

	public int getMem_no() {
		return mem_no;
	}

	public void setMem_no(int mem_no) {
		this.mem_no = mem_no;
	}

	public String getDept_no() {
		return dept_no;
	}

	public void setDept_no(String dept_no) {
		this.dept_no = dept_no;
	}

	public String getPosi_no() {
		return posi_no;
	}

	public void setPosi_no(String posi_no) {
		this.posi_no = posi_no;
	}

	public String getMem_nm() {
		return mem_nm;
	}

	public void setMem_nm(String mem_nm) {
		this.mem_nm = mem_nm;
	}

	public String getMem_tel() {
		return mem_tel;
	}

	public void setMem_tel(String mem_tel) {
		this.mem_tel = mem_tel;
	}

	public String getMem_addr1() {
		return mem_addr1;
	}

	public void setMem_addr1(String mem_addr1) {
		this.mem_addr1 = mem_addr1;
	}

	public String getMem_addr2() {
		return mem_addr2;
	}

	public void setMem_addr2(String mem_addr2) {
		this.mem_addr2 = mem_addr2;
	}

	public String getMem_birth() {
		return mem_birth;
	}

	public void setMem_birth(String mem_birth) {
		this.mem_birth = mem_birth;
	}

	public String getMem_id() {
		return mem_id;
	}

	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}

	public String getMem_pw() {
		return mem_pw;
	}

	public void setMem_pw(String mem_pw) {
		this.mem_pw = mem_pw;
	}

	public String getMem_mail() {
		return mem_mail;
	}

	public void setMem_mail(String mem_mail) {
		this.mem_mail = mem_mail;
	}

	public String getHire() {
		return hire;
	}

	public void setHire(String hire) {
		this.hire = hire;
	}

	public String getRetire() {
		return retire;
	}

	public void setRetire(String retire) {
		this.retire = retire;
	}

	public int getAuth() {
		return auth;
	}

	public void setAuth(int auth) {
		this.auth = auth;
	}

	@Override
	public String toString() {
		return "MemberVO [mem_no=" + mem_no + ", dept_no=" + dept_no + ", posi_no=" + posi_no + ", mem_nm=" + mem_nm
				+ ", mem_tel=" + mem_tel + ", mem_addr1=" + mem_addr1 + ", mem_addr2=" + mem_addr2 + ", mem_birth="
				+ mem_birth + ", mem_id=" + mem_id + ", mem_pw=" + mem_pw + ", mem_mail=" + mem_mail + ", hire=" + hire
				+ ", retire=" + retire + ", auth=" + auth + "]";
	}


}