package src.main.java.ddit.dao;

import java.util.List;

import com.ibatis.sqlmap.client.SqlMapClient;

import res.ddit.config.BuildedSqlMapClient;
import src.main.java.ddit.vo.MemberInfoVO;


public class MemberInfoDAOImpl implements IMemberInfoDAO {
	private static MemberInfoDAOImpl instance = null;
	private SqlMapClient smc = null;
	private MemberInfoDAOImpl() {
		if(smc==null) smc = BuildedSqlMapClient.getSqlMapClient();
	}
	
	public static MemberInfoDAOImpl getInstance() {
		if(instance==null) instance = new MemberInfoDAOImpl();
		return instance;
	}
	
	
	@Override
	public int insertMemInfo(MemberInfoVO memInfoVo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateMemInfo(MemberInfoVO memberInfoVo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteMemInfo(int infoNo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<MemberInfoVO> getMemInfoList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MemberInfoVO getMemInfo(int memNo) {
		// TODO Auto-generated method stub
		return null;
	}

	

}
