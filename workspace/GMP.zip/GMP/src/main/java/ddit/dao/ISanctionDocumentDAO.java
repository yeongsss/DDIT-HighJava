package src.main.java.ddit.dao;

import java.util.List;

import src.main.java.ddit.vo.SanctionDocumentVO;


public interface ISanctionDocumentDAO {

	/**
	 * 
	 * @param sanDocVo
	 * @return int
	 */
	public int insertSanDoc(SanctionDocumentVO sanDocVo);

	/**
	 * 
	 * @param sanDocVo
	 * @return int
	 */
	public int updateSanDoc(SanctionDocumentVO sanDocVo);
	
	/**
	 * 
	 * @param sanNo
	 * @return int
	 */
	public int deleteSanDoc(int sanNo);
	
	/**
	 * 
	 * @return List<SanctionDocumentVO>
	 */
	public List<SanctionDocumentVO> getSanDocList();

	/**
	 * 
	 * @param sanDocVo
	 * @return SanctionDocumentVO
	 */
	public List<SanctionDocumentVO> getSanDoc(SanctionDocumentVO sanDocVo);
	
}
