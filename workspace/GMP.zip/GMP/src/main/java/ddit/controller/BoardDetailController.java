//package ddit.controller;
//
//import java.io.IOException;
//import java.io.PrintWriter;
//
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//import com.google.gson.Gson;
//
//import ddit.service.BoardServiceImpl;
//import ddit.vo.BoardVO;
//
//@WebServlet("/board/boardDetail.do")
//public class BoardDetailController extends HttpServlet {
//	private static final long serialVersionUID = 1L;
//       
//	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		request.setCharacterEncoding("utf-8");
//		response.setCharacterEncoding("utf-8");
//		response.setContentType("text/html; charset=utf-8");
//		
////		String choice = request.getParameter("choice");
//		
//		String board_no = request.getParameter("board_no");
//		 
////		System.out.println("choice" + choice);
//		System.out.println("board_no ::"+board_no);
//		System.out.println("paramㅃㅃㅃ" + request.getParameter("param"));
//		
//		Gson gson = new Gson();
//		PrintWriter out = response.getWriter();
//		String jsonData = null;
//		
//		BoardServiceImpl service = BoardServiceImpl.getInstance();
//		BoardVO bVo = null;
//		
////		switch (choice) {
////		case "세부":
//			bVo = service.findBoard(Integer.parseInt(board_no));
//			jsonData = gson.toJson(bVo);
//			out.print(jsonData);
//			System.out.println(jsonData);
//			response.flushBuffer();
////			break;
//
////		default:
////			break;
////		}
//		
//	}
//
//	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		doGet(request, response);
//	}
//
//}
